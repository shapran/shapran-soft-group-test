class Tree:
    def __init__(self, value, root=None):
        # left and right child nodes
        self.lchild = None
        self.rchild = None
        # node value
        self.value = value
        # parent element for current node
        self.root = root

    def __contains__(self, key):
        return self.find(key)

    def add(self, value):
        # track current node (level)
        current_node = self
        # track parent node
        last_node = None
        # search the place to insert new node
        while current_node:
            last_node = current_node
            if value > current_node.value:
                current_node = current_node.rchild
            elif value < current_node.value:
                current_node = current_node.lchild
            else:
            # element already presented in tree
                return False

        # create new node and link it with parent
        new_node = Tree(value, last_node)
        if value > last_node.value:
            last_node.rchild = new_node
        else:
            last_node.lchild = new_node
        return True
    
    def find(self, value):
        # track current node (level)
        current_node = self
        # track parent node
        last_node = None
        # search if value exists
        while current_node:
            last_node = current_node
            if value == current_node.value:
                return True
            elif value > current_node.value:
                current_node = current_node.rchild
            else:
                current_node = current_node.lchild
        #element is not founded    
        return False

    def print(self):
        def print_layer(layer=[]):
            current_layer = []
            for node in layer:
                print(node.value, end=' ')
                if node.lchild is not None:
                    current_layer.append(node.lchild)
                if node.rchild is not None:
                    current_layer.append(node.rchild)
            print()        
            if current_layer:
                print_layer(current_layer)
                
        print_layer([self])


          
        
root = Tree(10)
root.add(9)
root.add(8)
root.add(11)
root.add(15)
root.add(16)
root.add(12)
root.add(2)

for x in range(0,18):
    if x in root:
        print(str(x) + ' in root')
    
print(root.find(11))
print(root.find(5))
 
root.print()

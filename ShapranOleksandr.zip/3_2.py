import os
import sys
from stat import *

def func(top):
    for f in os.listdir(top):
        pathname = os.path.join(top, f)
        mode = os.stat(pathname)[ST_MODE]
        if S_ISDIR(mode):
            func(pathname)
        elif S_ISREG(mode):
            print(pathname)

func('F:\\temp\\PyPDF2-1.26.0')

'''
import os

def func1(path):
    for root, dirs, files in os.walk(path):
        for file in files:        
            print(os.path.join(root,file) )

func('F:\\temp\\PyPDF2-1.26.0')
'''

def func(text):
    text = text.replace(" ", "").upper()
    return str(text) == str(text)[::-1]

print(func('Abc b a'))
print(func('xyzyq'))
print(func('Eve'))
